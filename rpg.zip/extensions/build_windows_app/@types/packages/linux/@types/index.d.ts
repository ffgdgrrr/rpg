/// <reference path="../../../@types/index.d.ts"/>

export * from "@editor/library-type/packages/builder/@types/protect";
