# Project Title

An blank extension.

## Development Environment

Node.js

## Install

```bash
# Install dependent modules
npm install
# build
npm run build
```
